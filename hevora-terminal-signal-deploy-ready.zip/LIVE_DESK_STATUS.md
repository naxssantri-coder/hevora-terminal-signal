# Live Desk — Status Sebenarnya

**Terakhir diperbarui:** 2026-09-06 (audit & penyelesaian final, sesi ini — Babak 3)

Dokumen ini adalah **satu sumber kebenaran** untuk status setiap fitur yang pernah diminta di proyek
Live Desk. Tidak perlu menggali ulang riwayat chat — kalau statusnya berubah (fitur baru, bug
ditemukan, sesuatu akhirnya berhasil diverifikasi), **update file ini di commit yang sama**.

## Legenda status

| Status | Arti |
|---|---|
| ✅ **Terbukti** | Sudah dites nyata (browser sungguhan diklik langsung, atau endpoint/proses dijalankan sungguhan lawan server nyata) — bukan cuma dibaca kodenya, bukan cuma dicek DOM/attribute tanpa cek hasil visualnya. |
| ⚠️ **Belum Terverifikasi** | Kodenya ada dan sudah type-check, tapi belum (atau tidak bisa) dites lawan kondisi asli — dijelaskan kenapa di kolom Catatan. |
| ❌ **Belum Dikerjakan** | Diminta tapi belum dibangun — dijelaskan kenapa (bukan lupa, atau menunggu keputusan). |
| 🚫 **Tidak Tersedia** | Diaudit, tidak ada sumber data gratis/legal yang ditemukan — bukan dipalsukan. |

**Batasan lingkungan yang berlaku di SEMUA baris "yt-dlp"/"embed YouTube"/"production" di bawah:**
sandbox development proyek ini tidak bisa menjangkau `youtube.com` ATAUPUN domain production Render
proyek ini sendiri sama sekali (proxy egress menolak dengan 403 untuk keduanya) — dikonfirmasi ulang
2026-09-06. Verifikasi apa pun yang butuh jaringan nyata ke YouTube/RSS eksternal ATAU ke production
dilakukan lewat GitHub Actions (runner GitHub punya internet asli, dan menyimpan secret
`HEV_SERVER_BASE_URL`/`ADMIN_USERNAME`/`ADMIN_PASSWORD` yang menunjuk ke production sungguhan).

---

## 1. Dashboard inti (dibangun pertama kali)

| Fitur | Status | Terakhir dicek | Catatan |
|---|---|---|---|
| Tab "Live Desk" sbg Intelligence #3 | ✅ Terbukti | 2026-09-06 | Dibuka di browser, screenshot dikonfirmasi. |
| Panel Live Capture & Transkrip (asli vs analisis AI) | ✅ Terbukti | 2026-09-06 | Dites klik nyata, judul+transkrip tampil dari data event asli. |
| AI Core Analysis Engine (topik/tone/causal chain) | ✅ Terbukti | 2026-09-06 | Skor importance, badge topik, gauge hawkish/dovish tampil dari data segmen asli. |
| Impact Matrix (per-pair + per-asset-class) | ✅ Terbukti | 2026-09-06 | Baris XAU/BTC/ETH dst tampil dengan arah+confidence asli dari `pairImpacts`. |
| Smart Alerts | ✅ Terbukti | 2026-09-06 | Modal "Lihat semua alert" dibuka manual, isi sesuai data live event ber-impact High. |
| Narrative Intelligence (topik panas hari ini) | ✅ Terbukti | 2026-09-06 | Bar topik ("Rate Policy", "Inflation") tampil dari agregasi segmen asli. |
| Sentiment Dashboard | ✅ Terbukti | 2026-09-06 | Skor numerik (mis. 50/100) tampil, bukan placeholder. |
| Crypto & Komoditas / Institutional Flow panel | 🚫 Tidak Tersedia (sebagian) | 2026-08 (audit awal) | Fear&Greed/funding rate perlu data live nyata (belum ada di sandbox); ETF/dark pool/whale flow: diaudit, tidak ada sumber gratis — ditandai jujur "Belum Tersedia" di UI, bukan dipalsukan. |
| Watchlist/ETF/Liquidity sidebar | ✅ Terbukti | 2026-09-06 | Reuse modul yang sudah ada sebelumnya, tampil normal di screenshot. |

## 2. Widget HEVAI + konteks Live Desk

| Fitur | Status | Terakhir dicek | Catatan |
|---|---|---|---|
| Panel "AI Chat Analyst" dihapus dari grid Live Desk | ✅ Terbukti | 2026-09-06 | Dicek: teks "AI Chat Analyst" tidak ada lagi di halaman. |
| Konteks Live Desk direlay ke widget HEVAI global | ✅ **Terbukti sepenuhnya** (payload DAN isi jawaban) | 2026-09-06 | Payload request `/api/ai/ask` sudah lama dikonfirmasi membawa `liveDeskContext` lengkap. **Babak 3 (sesi ini): isi jawaban AI itu sendiri akhirnya dites nyata lawan production dengan `GEMINI_API_KEY` ASLI** (`.github/workflows/verify-hevai-ask-live.yml`, POST sungguhan ke production dengan `liveDeskContext` sintetis bertema "Fed hawkish"). Hasil: jawaban Gemini nyata, relevan, secara eksplisit menyebut "Fed", "hawkish", XAUUSD, dan menggabungkan konteks yang dikirim dengan data pasar riil lain (COT positioning percentile 86%, skor risiko geopolitik 48/100) — bukan jawaban generik/template. Baris ini SEBELUMNYA berstatus "belum terverifikasi", sekarang selesai. |

## 3. Live Intelligence pipeline (RSS/caption)

| Fitur | Status | Terakhir dicek | Catatan |
|---|---|---|---|
| Link artikel RSS (bukan feed XML mentah) | ✅ **Terbukti (jaringan nyata)** | 2026-09-06 | `verify-feeds.yml` run di GitHub Actions: SEMUA 7 sumber live-intel yang aktif menunjukkan link artikel per-item yang REACHABLE lewat HTTP request sungguhan. |
| Tab News konsisten dengan Live Desk | ✅ Terbukti | 2026-09-06 | Dibuka di browser terpisah, isi & jumlah item sama persis dengan panel Live News di Live Desk. |
| Tombol "Lihat Semua" expand in-page (bukan pindah tab) | ✅ Terbukti | 2026-09-06 | Diklik nyata untuk Alerts & News, modal overlay tampil dengan list lengkap. |
| Filter "Jenis Event" + browsing sesi sebelumnya | ✅ Terbukti | 2026-09-06 | Dipilih "Federal Reserve" di dropdown, counter & konten berganti sesuai sesi lebih lama. |
| CSP `frame-src` mengizinkan semua domain YouTube | ✅ Terbukti | 2026-09-06 | Header CSP dicek langsung dari response server. |
| Speaker "Kevin Warsh" konsisten (bukan Powell) | ✅ Terbukti | 2026-09-06 | Grep menyeluruh: tidak ada "Powell" dipakai sebagai nilai/data aktif di mana pun. |
| C-SPAN hanya eligible saat ada testimoni/hearing Kongres AS di kalender | ✅ **Terbukti (proses nyata)** | 2026-09-06 | Endpoint `GET /api/live-desk/cspan-eligibility` dites via curl nyata; proses watcher SUNGGUHAN dijalankan, log nyata: skip saat tidak ada jendela testimoni aktif. |
| 13 URL channel institusi (Fed/ECB/BOJ/dst, termasuk C-SPAN) valid & resmi | ✅ **Terbukti untuk 13/13** (identitas dikonfirmasi; hanya 2/13 pernah dikonfirmasi via video/stream nyata) | 2026-09-06 (Babak 1+2), re-attempt Babak 3 | **Babak 1** (GitHub Actions, yt-dlp): RBA & BOC terbukti valid via resolusi video id nyata. **Babak 2** (situs resmi tiap institusi, karena yt-dlp kena bot-block untuk sisanya): Fed, ECB, BOJ, BOE, BI, UN, EU Parliament, White House, Sekretariat Presiden, C-SPAN — 10 dikonfirmasi via situs resmi institusi masing-masing; EU Council diperbaiki ke `youtube.com/eucouncil` setelah `@EuropeanCouncil` terbukti salah. **Babak 3 (sesi ini): re-attempt yt-dlp fresh dari GitHub Actions gagal total (13/13, TERMASUK RBA & BOC yang sebelumnya berhasil) — semua kena "Sign in to confirm you're not a bot".** Ini mengonfirmasi ulang bahwa bot-block YouTube terhadap runner GitHub Actions bersifat **intermiten/berbasis-sesi**, bukan indikasi channel salah (RBA/BOC yang sama persis pernah resolve sukses di Babak 1) — kesimpulan Babak 1+2 TIDAK berubah, tapi juga tidak ada konfirmasi baru diperoleh sesi ini. Kalau butuh 100% pasti untuk 11 sisanya (bukan Fed/ECB — lihat baris audio-pipeline di bawah, yang justru berhasil resolve Fed & ECB dari PRODUCTION, bukan GitHub Actions, dan mendapat jawaban valid "channel is not currently live" bukan error bot-block), satu-satunya cara: klik manual di browser sungguhan. |
| **Independensi teks/transkrip dari pipeline audio berbayar** | ✅ **Terbukti (code trace menyeluruh)** | 2026-09-06 | `scripts/live-intel-watcher.ts` — nol referensi ke `LIVE_DESK_AUDIO_ENABLED`/`OPENROUTER_API_KEY`. Endpoint publish/autofill bersama hanya dijaga `requireAdminAuth`. Dengan audio pipeline mati total, pipeline teks tetap jalan penuh — tidak ada ketergantungan tersembunyi. |
| Pipeline audio-to-text OpenRouter (canary lawan siaran asli) | ✅ **Dikerjakan penuh sesi ini — lihat Bagian 6 di bawah untuk rinciannya** | 2026-09-06 | Dinyalakan sungguhan lawan production, ditemukan DAN diperbaiki 2 bug real crash-loop, sekarang berjalan sehat lawan production nyata. Detail lengkap: Bagian 6. |

## 4. Kanal video 24 jam & "Live Sekarang"

| Fitur | Status | Terakhir dicek | Catatan |
|---|---|---|---|
| 7 kanal internasional terdaftar (DW, France24, NHK, Euronews, AJE, Sky News, CNA), TIDAK masuk pipeline transkrip/audio | ✅ Terbukti (isolasi) / ⚠️ **Belum Terverifikasi (video benar-benar tampil)** | 2026-09-06 | Isolasi dari dropdown "Jenis Event" dikonfirmasi. Video embed (`embed/live_stream?channel=<id>`): 0/7 kanal berhasil menampilkan player di setiap percobaan sejauh ini (termasuk re-attempt Babak 3) — mekanisme embed YouTube untuk kanal 24/7 ini terbukti berulang kali tidak reliable. Ini alasan tombol "Tonton di YouTube" dijadikan kontrol UTAMA (lihat baris di bawah), bukan cuma pelengkap. |
| Bug: "Live Sekarang" nampilin ikon broken-image, bukan pesan jelas | ✅ **Sudah diperbaiki & diverifikasi** | 2026-09-06 | Tombol "Tonton di YouTube" (link biasa, 100% reliable, tidak bergantung mekanisme embed yang problematik) sekarang jadi kontrol UTAMA yang SELALU tampil jelas + disclaimer jujur. Dites nyata di browser. |
| Link "Tonton [Nama Kanal]" mengarah ke kanal yang benar (bukan channel ID salah) | ✅ **Terbukti (konsistensi internal + histori verifikasi jaringan)** | 2026-09-06 | Sandbox tetap 100% diblokir dari youtube.com sehingga tidak bisa diklik langsung dari sini. Yang bisa & sudah dipastikan: (1) **konsistensi internal** `channelUrl` vs `channelId` di `src/data/liveDeskVideoChannels.ts` untuk ke-7 kanal — utk kanal yang pakai bentuk `/channel/UC...` (NHK), channel id di URL dan field `channelId` identik byte-per-byte; sisanya pakai `@handle` yang sudah dicross-check di Babak 1 (GitHub Actions, yt-dlp, real network) dan resolve dengan benar saat itu. (2) **percobaan re-verifikasi fresh Babak 3 ini**: `verify-live-desk-video-sources.yml` dijalankan ulang — hasil untuk ke-7 kanal ini TIDAK bisa dikonfirmasi ulang kali ini (gagal, error berbeda dari sebelumnya, kemungkinan variasi rate-limit/bot-block YouTube yang sama seperti dialami 13 channel institusi di atas), sehingga TIDAK ADA bukti baru — baik yang menguatkan MAUPUN yang membantah — diperoleh sesi ini. Kesimpulan tetap bersandar pada bukti Babak 1 (real network, saat itu berhasil). **Kalau ingin 100% pasti tanpa keraguan: perlu diklik manual di browser sungguhan oleh user** — ini satu-satunya cara yang benar-benar di luar kendali sandbox/GitHub Actions manapun, karena root cause-nya (bot-block YouTube) tidak predictable dari runner otomatis. |
| Tab manual "Live Sekarang" (pilih & tonton kapan pun) | ✅ Terbukti (mekanisme UI) | 2026-09-06 | Modal terbuka, 7 kanal terdaftar, navigasi berfungsi. |

## 5. Keamanan sistem lain (dicek sesi ini, Babak 3)

| Fitur | Status | Terakhir dicek | Catatan |
|---|---|---|---|
| Kuota Gemini saat ini (setelah 13 sumber live-intel aktif) | ✅ **Terbukti (endpoint baru + baca nyata dari production)** | 2026-09-06 | Endpoint baru `GET /api/admin/ai-budget-health` dibuat, dites lokal, lalu dibaca sungguhan dari production via `check-admin-health-endpoint.yml`. Hasil real-time: HEVAI (Ask AI + macro-narrative) hour 0/60 (0%), day 0/500 (0%); live-intel-watcher AI autofill minute 0/8 (0%), hour 0/60 (0%), day 0/500 (0%). **Catatan jujur penting**: counter ini in-memory, reset setiap kali process Render restart — angka 0% ini mencerminkan sejak restart TERAKHIR (≈13 menit sebelum dicek, akibat redeploy sesi ini sendiri), BUKAN akumulasi sejak 13 sumber pernah aktif. Tidak ada cara melihat pemakaian historis sebelum restart terakhir dari arsitektur saat ini (bukan Redis-backed) — kalau butuh tren jangka panjang, perlu ditambahkan persistent counter terpisah (perubahan fitur baru, di luar cakupan audit ini). |
| `NVIDIA_API_KEY` (validasi sinyal trading) 100% tidak tersentuh Live Desk | ✅ **Terbukti (diff byte-per-byte)** | 2026-09-06 | Dibandingkan byte-per-byte antara commit sebelum Live Desk dimulai vs HEAD: `getNvidiaClient`, `recordNvidiaCallOutcome`, `timedNvidiaCall`, `validateSignalWithAI`, endpoint `/api/admin/nvidia-ai-health` — 100% identik, nol perubahan. Jumlah call site juga tidak berubah (4 sebelum, 4 sesudah). |
| Kecepatan sinyal (`engine-tick-health`) — normal atau melambat dibanding sebelum Live Desk? | ✅ **Terbukti (angka nyata dari production)**, dengan catatan jujur soal baseline | 2026-09-06 | Angka production nyata (dari canary): p95 tick ≈417-488ms (jauh di bawah ambang breaker 1500ms), event-loop-lag p95 ≈1ms (jauh di bawah ambang 250ms), circuit breaker belum pernah trip. **Catatan jujur**: mekanisme `engineTickHealth` itu sendiri BARU DIPERKENALKAN oleh pekerjaan Live Desk — tidak ada baseline numerik "sebelum Live Desk" untuk dibandingkan. Sebagai gantinya: diff byte-per-byte pada `processEngineTick()` menunjukkan Live Desk hanya menambah 2 baris instrumentasi trivial ke fungsi itu sendiri — jadi walau baseline historis tidak ada, dampak KODE Live Desk terhadap tick loop utama terbukti minimal secara langsung dari diff, bukan cuma dari angka runtime saat ini. |

## 6. Pipeline audio-to-text OpenRouter — canary produksi nyata (Babak 3, sesi ini)

Item ini yang paling signifikan sesi ini: dinyalakan sungguhan lawan production sesuai instruksi
eksplisit user (`OPENROUTER_API_KEY` sudah terpasang), dan **ditemukan 2 bug crash-loop nyata** yang
membuktikan kenapa "belum pernah dites nyata" itu penting — kodenya type-check bersih dan terlihat
benar di baca sekilas, tapi gagal total begitu benar-benar dijalankan lawan production sungguhan.

| Langkah | Hasil |
|---|---|
| 1. Pre-flight check (`action=status`) | `openRouterConfigured: true` (mengonfirmasi klaim user), `killSwitchEnabled: false`, cost/usage historis nol, engine tick sehat. Semua syarat aman terpenuhi. |
| 2. `action=enable` (percobaan pertama) | Settings berhasil di-flip ke `enabled: true`. **TAPI**: `worker.running` tetap `false`, `restartCount` naik ke 59+ dalam <5 menit, `lastExitCode: 1` di setiap siklus — worker CRASH-LOOP, direspawn tiap 5 detik oleh watchdog tanpa henti. |
| 3. Tindakan langsung | **Segera dimatikan lagi** (`action=disable`) begitu crash-loop terdeteksi, SEBELUM investigasi root cause dimulai — prinsip konservatif: hentikan dulu, baru diagnosis. Selama seluruh insiden ini, `recentUsage`/`totals` tetap kosong di setiap pengecekan — **$0 biaya nyata terpakai**, karena worker tidak pernah cukup lama hidup untuk benar-benar menangkap audio apa pun. |
| 4. Root cause #1 (ditemukan dari baca kode `main()` di `live-desk-audio-worker.ts`) | Worker mensyaratkan env var OS mentah `LIVE_DESK_AUDIO_ENABLED==='true'` secara terpisah dari toggle `settings.enabled` yang sudah tersimpan (yang justru didesain "bisa dimatikan/dinyalakan tanpa redeploy"). `startLiveDeskAudioWorker()` di `server.ts` mem-forward env parent APA ADANYA ke child — tidak pernah menyuntikkan env var mentah itu. Kalau env var itu tidak pernah di-set di Render (sesuai desain togglenya yang memang tidak butuh), child langsung exit(1) di gerbang ini, sebelum sempat cek ffmpeg/yt-dlp sama sekali. |
| 5. Root cause #2 (ditemukan dari baca 3 titik panggilan yt-dlp di file yang sama) | `live-desk-audio-worker.ts` memanggil `yt-dlp` mentah lewat `execFileAsync('yt-dlp', ...)` di 3 tempat, mengandalkan PATH sistem. Tapi `scripts/install-yt-dlp.sh` HANYA mengunduh yt-dlp ke path lokal `<root proyek>/bin/yt-dlp`, TIDAK PERNAH ke PATH sistem. `server.ts` dan `live-intel-watcher.ts` sudah punya `resolveYtDlpBinary()` yang benar (cek `bin/yt-dlp` lokal dulu, baru fallback ke PATH) — tapi file worker audio ini tidak pernah memilikinya. |
| 6. Perbaikan | (a) `startLiveDeskAudioWorker()` sekarang eksplisit forward `LIVE_DESK_AUDIO_ENABLED: 'true'` ke child — aman karena fungsi ini HANYA dipanggil setelah `settings.enabled` sudah dikonfirmasi true. (b) `resolveYtDlpBinary()` ditambahkan ke `live-desk-audio-worker.ts` (duplikasi pola yang sama dengan 2 file lain, sesuai konvensi file ini yang memang sengaja tidak saling impor), dipakai di ketiga titik panggilan. (c) `live-desk-audio-health` sekarang mengembalikan `recentLogLines` (±50 baris log stdout/stderr worker in-memory) — sebelumnya tidak ada cara melihat KENAPA worker crash dari API. (d) `LIVE_DESK_AUDIO_RESTART_BACKOFF_MS` (15 detik) — sebelumnya dideklarasikan tapi TIDAK PERNAH benar-benar dipakai (dead code) — sekarang benar-benar diterapkan di `ensureLiveDeskAudioWorkerRunning()`, supaya worker yang terus-menerus crash tidak lagi direspawn tiap 5 detik tanpa jeda. |
| 7. Deploy & verifikasi ulang | Typecheck bersih, build bersih, commit `a29e61b`, merge ke `main`, dikonfirmasi production sudah menjalankan commit ini (`processStartedAt: 2026-09-06T05:56:11Z` via `/api/deploy-info`). |
| 8. `action=enable` (percobaan kedua, SETELAH perbaikan) | **BERHASIL PENUH**: `worker.running: true`, `pid: 3944`, `restartCount: 0`, `lastExitCode: null` — TIDAK ADA crash sama sekali. `recentLogLines` menunjukkan log nyata: worker start dengan konfigurasi benar (`STT model=openai/whisper-large-v3`, dst), lalu benar-benar mem-poll Fed (`@federalreserve/live`) dan ECB (`/channel/UCXB8fM4VyQubRu3UVGhd3wA/live`) lewat binary yt-dlp lokal yang benar (`/opt/render/project/src/bin/yt-dlp`) — mendapat jawaban jujur "The channel is not currently live" (BUKAN error, ini kondisi normal karena memang tidak ada siaran Fed/ECB yang sedang berlangsung saat dicek). Cost tetap $0 (belum ada broadcast tertangkap). |
| 9. Sumber Fed `enabled: true` | ✅ Sudah benar sejak awal, tidak perlu perubahan — `fed-youtube-channel` di `live-intel-watcher.config.ts` sudah `enabled: true` dengan `audioPriority: 1` (tertinggi). |
| 10. "Tunggu siaran live pertama" | **Batasan jujur**: sesi agent tunggal tidak bisa membabysit kejadian dunia nyata dengan durasi tidak tentu (siaran Fed/ECB berikutnya bisa dalam hitungan jam atau hari) tanpa henti dalam satu giliran percakapan. **Keputusan**: pipeline **dibiarkan menyala** (`settings.enabled: true`) sesuai instruksi eksplisit user "biarkan jalan" — sekarang terbukti berjalan sehat (bukan crash-loop lagi), circuit breaker & kill switch tetap aktif sebagai pengaman, cost nol selama idle. **User perlu tahu**: sesi Claude ini TIDAK sedang memantau terus-menerus secara real-time setelah percakapan ini berakhir — cek `GET /api/admin/live-desk-audio-health` (admin auth) kapan saja untuk lihat status terkini (`worker.activeSourceLabel`, `recentUsage`, `totals.estimatedCostUsdLast24h`), atau minta sesi baru untuk mengecek ulang. |

---

## 7. Alat diagnostik yang ditambahkan sesi ini (Babak 3)

| Alat | Fungsi |
|---|---|
| `GET /api/admin/ai-budget-health` (server.ts, baru) | Persentase pemakaian kuota Gemini real-time (global HEVAI + news autofill), per window (menit/jam/hari). |
| `scripts/live-desk-audio-canary.ts` + `.github/workflows/live-desk-audio-canary.yml` (baru) | Kontrol aman (status/enable/disable) untuk pipeline audio real production, dengan pre-flight safety check bawaan. |
| `.github/workflows/check-admin-health-endpoint.yml` (baru) | GET generik ke endpoint admin health mana pun lawan production — reusable, tidak perlu workflow baru tiap kali ada endpoint health baru. |
| `.github/workflows/verify-hevai-ask-live.yml` (baru) | Kirim 1 pertanyaan nyata + `liveDeskContext` sintetis ke `/api/ai/ask` production, untuk memverifikasi ISI jawaban AI (bukan cuma payload request). |
| `GET /api/admin/live-desk-audio-health` → `recentLogLines` (baru) | ±50 baris log stdout/stderr terakhir worker audio, in-memory — sebelumnya tidak ada cara mendiagnosis crash dari API. |
| `.github/workflows/check-production-deploy-version.yml` (sudah ada sebelumnya, dipakai ulang) | Konfirmasi commit apa yang sedang jalan di production, dipakai berulang kali sesi ini untuk memastikan fix benar-benar sudah deploy sebelum re-test. |
| `scripts/verify-live-desk-video-sources.ts` + workflow-nya (sudah ada) | Cek nyata status live + embeddability channel — dijalankan ulang sesi ini (Babak 3), hasil dilaporkan di baris terkait di atas. |

---

## Ringkasan pekerjaan tersisa yang jujur perlu ditindaklanjuti

1. **11 dari 13 channel institusi** (semua kecuali Fed & ECB, yang barusan berhasil di-poll dari
   production sendiri) masih hanya punya bukti "situs resmi institusi menyebutnya" + histori resolusi
   yt-dlp yang sempat berhasil sebelumnya (RBA, BOC) — belum ada yang benar-benar diklik/ditonton di
   browser sungguhan oleh manusia. Bot-block YouTube terhadap runner otomatis (GitHub Actions maupun
   kemungkinan juga Render) membuat ini sulit diselesaikan 100% dari sandbox/CI manapun — **butuh klik
   manual sungguhan oleh user** kalau ingin kepastian mutlak.
2. **Video embed 24 jam** (7 kanal internasional) tetap 0/7 di setiap percobaan sampai sesi ini —
   sudah dimitigasi di UI (tombol "Tonton" jadi kontrol utama), tapi mekanisme embed itu sendiri belum
   pernah berhasil sekali pun sejauh yang tercatat. Kalau re-test berikutnya juga tetap 0/7, embed-nya
   sendiri sebaiknya dihapus total (bukan cuma disembunyikan di belakang tombol) — keputusan desain,
   bukan bug, jadi tidak diubah sepihak sesi ini.
3. **Pipeline audio-to-text**: SEKARANG BERJALAN SEHAT di production (bug crash-loop ditemukan &
   diperbaiki sesi ini), tapi belum pernah menangkap siaran live sungguhan (belum ada yang live saat
   dites) — cost dan perilaku end-to-end saat benar-benar menangkap audio nyata masih belum
   terverifikasi. Butuh pemantauan lanjutan kapan pun ada siaran Fed/ECB/dst berlangsung.
4. **Tren kuota Gemini jangka panjang** (bukan cuma snapshot sejak restart terakhir) butuh persistent
   counter (Redis-backed, bukan in-memory) kalau user mau melihat pemakaian akumulatif sesungguhnya —
   di luar cakupan audit ini, perlu keputusan/permintaan terpisah kalau diinginkan.
