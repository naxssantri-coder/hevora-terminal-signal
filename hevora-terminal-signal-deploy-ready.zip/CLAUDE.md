# HEVORA Signal Terminal — instructions for Claude Code

## Standing instruction: autonomous audit/investigation/bug-fix work

When the user gives a task on this codebase that is an **audit, investigation, or bug fix** with
clear scope, work it end-to-end autonomously in one pass — audit, implement, typecheck, sanity
test, commit, push, and merge to `main` — **without pausing mid-task to ask for confirmation**.
This applies every time, not just when restated.

Still apply everything already established for this project while doing that:

- **XAUUSD-only scope.** Never change behavior for any other pair (BTCUSDT, ETHUSDT, SOLUSDT,
  EURUSD, GBPUSD, USDCHF, USDCAD, or any data-only pair) unless the user explicitly asks for that
  pair. When a helper function is shared across pairs, branch on `pairId === 'XAUUSD'` rather than
  changing the shared path.
- **No fabricated/hardcoded data.** If real data isn't available (e.g. this sandbox's egress to
  Yahoo Finance / gold-api.com / Binance / etc. is blocked — confirmed repeatedly this project),
  say so plainly and use `scripts/backtest-xau-engine.ts` (or a similar one-off script) via the
  `.github/workflows/backtest-xau.yml` GitHub Actions workflow, which runs on GitHub's own
  runners that do have real internet access. Never substitute synthetic data for a real result
  without labeling it as synthetic/illustrative, and never present an estimate as if it were a
  live account/production read.
- **Stop and report before any risk/money trade-off decision.** A trade-off that changes how much
  a user can gain or lose (SL/TP sizing philosophy, lot-sizing behavior, confidence thresholds,
  anything that shifts realized risk) is not a unilateral call — implement the investigation/
  measurement, then report the numbers and stop for the user's decision before touching live
  logic. Pure bug fixes, visibility/observability additions (logging, read-only debug endpoints),
  and safety gates that only ever make the system more conservative (e.g. refusing to trade on
  stale data) do not require this pause — those can go straight through the full pipeline above.
- **End with a short summary**, not a step-by-step narration: what changed, and the test/
  verification results (typecheck status, sanity-test results, what was confirmed live vs. what
  couldn't be verified and why).

## Project-specific conventions already in use

- Branch: `claude/xauusd-signal-engine-redesign-7rid24`. If it's already merged into `main`,
  restart it from latest `main` (`git checkout -B <branch> origin/main`) rather than stacking on
  merged history.
- Direct-to-`main` merges (fast-forward, no PR) are the norm on this project unless the user asks
  for a PR — confirmed repeatedly across sessions.
- This sandbox cannot reach Yahoo Finance, gold-api.com, Binance, Bybit, KuCoin, OKX, or
  CoinGecko (egress blocked). For anything needing real market data, use the GitHub Actions
  workaround above (`mcp__github__actions_run_trigger` with `workflow_id: backtest-xau.yml`,
  then read the job log via `mcp__github__get_job_logs`).
- Admin-only read-only debug endpoints follow the `requireAdminAuth`-gated
  `/api/admin/xau-*-health` pattern (see `xau-candle-health`, `xau-autotrade-health`) — reuse it
  for new visibility work instead of inventing a new auth/response shape.
- `scripts/backtest-xau-engine.ts` is the walk-forward backtest harness for XAUUSD (OLD vs NEW
  engine, plus the cancelled fase-2 soft/hard-SL comparison kept for reference). Extend it rather
  than writing a parallel one when a new backtest question comes up.
