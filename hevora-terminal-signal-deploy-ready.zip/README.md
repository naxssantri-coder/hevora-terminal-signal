# HEV Terminal Signal by HEVORA — Render & Production Architecture Guide

Terminal Signal ini telah direfaktur secara menyeluruh agar **100% konsisten untuk semua user** dan **siap di-deploy ke Render Web Service (Node.js)** atau platform persistent server serverless tanpa masalah state hilang atau signal berbeda antar user.

---

## 🚀 Panduan Setup Deploy di Render (Render Web Service)

Agar aplikasi berjalan di Render sebagai **Single Persistent Node.js Service**:

### 1. Buat Web Service Baru di Render
1. Buka [Render Dashboard](https://dashboard.render.com) -> Klik **New +** -> **Web Service**.
2. Hubungkan repository GitHub HEVORA Anda.
3. Konfigurasi Settings berikut:
   - **Environment:** `Node`
   - **Region:** Singapore (`singapore`) / nearest.
   - **Branch:** `main`
   - **Build Command:** `npm run build`
   - **Start Command:** `npm start`
   - **Instance Type:** Starter / Standard (Single Instance Mandate).

> 🚨 **MANDAT SINGLE-INSTANCE**: Pastikan **TIDAK mengaktifkan Auto-Scaling / Multiple Instances** di Render. Engine HEVORA menggunakan loop background persistent internal untuk sinkronisasi harga & signal. Jika dijalankan dalam multiple instances, harga dan signal dapat mengalami *race condition* jika tidak dihubungkan ke Redis.

---

### 2. Upstash Redis / Vercel KV Setup (Shared Persistence)
Meskipun berjalan sebagai persistent Node.js process, mengonfigurasi Upstash Redis memastikan data signal dan harga bertahan meskipun terjadi server restart atau redeployment.

Tambahkan **Environment Variables** di Render Dashboard (**Settings -> Environment Variables**):

| Variable Name | Deskripsi | Wajib? |
|--------------|-----------|--------|
| `PORT` | Bind port untuk Cloud container (default auto-set oleh Render / 3000) | **Otomatis** |
| `UPSTASH_REDIS_REST_URL` / `KV_REST_API_URL` | REST Endpoint URL Upstash Redis / Vercel KV | **Rekomendasi** |
| `UPSTASH_REDIS_REST_TOKEN` / `KV_REST_API_TOKEN` | Access Token Upstash Redis / Vercel KV | **Rekomendasi** |
| `GEMINI_API_KEY` | Key Google Gemini AI untuk Validator Re-Analysis | Opsional |
| `ADMIN_SECRET` | Secret key untuk endpoint reset `/api/admin/reset-signals` | **Rekomendasi** |

---

## 🔒 Fitur Keandalan & Ketahanan Engine HEVORA

1. **Single Source of Truth**: Semua client (`/api/signals` & `/api/prices`) membaca data harga & signal yang sama dari Redis / Memory Server.
2. **Persistent Replacement Mechanism (`readyForReplacementAt`)**: Signal yang selesai (`TP2 Hit`, `Stop Loss Hit`, atau `Invalidated`) memiliki field timestamp `readyForReplacementAt`. Penggantian signal bertahan meskipun server di-restart di tengah delay replacement.
3. **Persistensi Sinyal Unresolved**: Sinyal berstatus `Running` atau `TP1 Hit` **TIDAK AKAN PERNAH** diganti paksa berdasarkan timeout/umur jam. Sinyal berjalan hingga secara alami menyentuh TP2 atau SL.
4. **Invalidated Status**: Sinyal `Waiting Entry` yang dilompati harga secara signifikan tanpa mentrigger order langsung diubah ke status `Invalidated` dan diganti setup baru.
5. **Throttling & Circuit Breakers**:
   - Polling harga Forex/Emas dibatasi maksimal 1x per 5 detik.
   - Circuit Breaker otomatis menonaktifkan endpoint API luar selama 30 detik jika mengalami 5 kegagalan berturut-turut.
   - Ticker Binance Crypto difilter khusus simbol `BTCUSDT`, `ETHUSDT`, `SOLUSDT` untuk menghemat bandwidth & kuota API.
6. **Batas Riwayat**: Array `history` pada sinyal dibatasi maksimal 20 entri terakhir.
7. **Panduan Risiko (Risk Guidance)**: Setiap sinyal dilengkapi panduan lot dan kalkulasi risiko rupiah (maks 1-2% modal).

---

## 🛠️ Endpoint Admin Reset
Jika Anda ingin mereset seluruh sinyal secara manual dari Admin Terminal:
`POST /api/admin/reset-signals`
Headers: `x-admin-secret: <ADMIN_SECRET_ANDA>`

---

## 📡 HEV Live Intelligence Watcher

Script standalone (`scripts/live-intel-watcher.ts`) yang memantau sumber live gratis/legal
(YouTube Live auto-caption, RSS resmi bank sentral/pemerintah, live-blog resmi), menyaring teks
relevan, mengirim ke AI untuk analisis terstruktur, lalu otomatis mempublikasikan sebagai
**Live Intelligence** event (muncul di tab **Intel**) kalau dampaknya cukup signifikan. Berjalan
**terpisah** dari `server.ts` - server utama tetap ringan, watcher bisa dimatikan/dinyalakan
kapan saja tanpa restart server.

### 1. Isi `.env`

Watcher butuh env var yang **sama** dengan yang sudah dipakai `requireAdminAuth` di server (tidak
ada credential terpisah):

```bash
# Wajib - kredensial admin, dipakai watcher untuk HTTP Basic Auth ke server
ADMIN_USERNAME="hevora_admin_821c0a"
# Salah satu dari dua ini wajib diisi:
ADMIN_PASSWORD="password_plaintext_anda"        # opsi 1: password asli
ADMIN_PASSWORD_HASH="sha256_hash_password_anda" # opsi 2: hash-nya saja (watcher boleh pakai
                                                 # string hash ini langsung sebagai "password" -
                                                 # requireAdminAuth menerima keduanya)

# Wajib di server (bukan di watcher) - tanpa ini endpoint ai-autofill akan selalu gagal
GEMINI_API_KEY="key_gemini_anda"

# Opsional - default http://localhost:3000, ganti kalau watcher menunjuk ke server yang
# sudah di-deploy (Render/dst), bukan server lokal
HEV_SERVER_BASE_URL="https://domain-terminal-anda.com"
```

Taruh di `.env` (dibaca otomatis oleh watcher lewat `dotenv/config`) atau set langsung sebagai
environment variable proses. `GEMINI_API_KEY` harus ada di environment **server** (server.ts),
bukan di watcher - watcher hanya memanggil endpoint-nya, tidak memanggil Gemini langsung.

### 2. Aktifkan 1 source di config

Buka `scripts/live-intel-watcher.config.ts`, semua source default `enabled: false`. Contoh
mengaktifkan 1 RSS source setelah URL asli terisi:

```ts
{
  id: 'fed-press-releases',
  kind: 'rss',
  label: 'Federal Reserve - Press Releases',
  enabled: true,               // <- ubah dari false ke true
  feedUrl: 'https://...',      // <- isi URL RSS .xml asli (lihat komentar di file untuk cara cek)
  pollIntervalMs: 60_000,
},
```

Setiap entry di `SOURCES` punya komentar yang menjelaskan format field yang diharapkan (URL RSS
langsung vs CSS selector untuk live-blog vs URL video/channel YouTube) - baca komentarnya sebelum
mengisi. Untuk source `youtube-live-captions`, pastikan binary `yt-dlp` sudah terinstall dan ada
di PATH (https://github.com/yt-dlp/yt-dlp) - watcher akan skip source itu dengan warning kalau
tidak ditemukan, bukan crash.

### 3. Jalankan watcher

```bash
npm run watch:live-intel
```

Log akan menunjukkan source mana yang aktif dipantau, kapan sebuah blok teks di-flush ke AI
autofill, hasil analisisnya (tone/verdict/impact), dan apakah dipublikasikan atau cuma di-log
(impact Low). Hentikan dengan `Ctrl+C` - state dedup otomatis tersimpan sebelum proses keluar.

### 4. Cek hasilnya di tab Intel

Buka aplikasi -> tab **Intel** -> event yang berhasil dipublikasikan (impact Medium/High) akan
muncul di section **Live Intelligence** di bagian atas (badge merah berdenyut, di atas strip
follow YouTube/Telegram). Klik salah satu card untuk lihat detail lengkap: ringkasan, tabel
Market Effects per aset, dan transkrip mentah aslinya. Event dengan impact Low sengaja **tidak**
dipublikasikan (hanya tercatat di log watcher) supaya tab Intel tidak penuh update rendah-signal.
