// One-off verification (2026-08-31, "chart & header must show the SAME number" audit) for the
// XAUUSD chart replacement (TradingView widget -> XauLightweightChart, reading
// /api/market/xau-intraday). Pulls REAL data from production (this sandbox cannot reach Render
// directly - same GitHub-Actions-run pattern as every other scripts/audit-*.ts/verify-*.ts in this
// repo) and proves, with real numbers rather than assumption, that the new chart endpoint's latest
// close is genuinely the same feed as /api/prices (the header/ticker) - not merely "close enough".
//
// No fabricated conclusions: if either endpoint fails, or the two disagree, this reports that
// plainly rather than asserting success.

const BASE_URL = process.env.HEV_PRODUCTION_URL || 'https://hevora-terminal-signal-production-2.onrender.com';

async function main() {
  console.log('===== XAUUSD chart single-source-of-truth verification =====');
  console.log(`Run at: ${new Date().toISOString()}`);
  console.log('');

  console.log('--- /api/prices (header/ticker/watchlist feed) ---');
  let headerPrice: number | null = null;
  let headerUpdatedAt: string | null = null;
  try {
    const res = await fetch(`${BASE_URL}/api/prices`);
    const data: any = await res.json();
    headerPrice = data?.XAUUSD?.price ?? null;
    headerUpdatedAt = data?.XAUUSD?.lastUpdated ?? null;
    console.log(`price=${headerPrice} lastUpdated=${headerUpdatedAt} isStale=${data?.XAUUSD?.isStale}`);
  } catch (e: any) {
    console.log(`FAILED: ${e?.message || e}`);
  }
  console.log('');

  console.log('--- /api/market/xau-intraday?interval=5m (new chart endpoint) ---');
  let chartLastClose: number | null = null;
  let chartLastCandleTime: number | null = null;
  try {
    const res = await fetch(`${BASE_URL}/api/market/xau-intraday?interval=5m`);
    const data: any = await res.json();
    const candles = Array.isArray(data?.candles) ? data.candles : [];
    console.log(`interval=${data?.interval} candleCount=${candles.length} source=${data?.source}`);
    if (candles.length > 0) {
      const last = candles[candles.length - 1];
      chartLastClose = last.c;
      chartLastCandleTime = last.t;
      console.log(`Last candle: t=${new Date(last.t).toISOString()} o=${last.o} h=${last.h} l=${last.l} c=${last.c}`);
    } else {
      console.log('No candles returned - nothing to compare (see xauChartEmpty handling on the frontend for this case).');
    }
  } catch (e: any) {
    console.log(`FAILED: ${e?.message || e}`);
  }
  console.log('');

  console.log('--- /api/market/xau-intraday?interval=15m (aggregation sanity check) ---');
  try {
    const res = await fetch(`${BASE_URL}/api/market/xau-intraday?interval=15m`);
    const data: any = await res.json();
    const candles = Array.isArray(data?.candles) ? data.candles : [];
    console.log(`interval=${data?.interval} candleCount=${candles.length}`);
    if (candles.length > 0) {
      const last = candles[candles.length - 1];
      console.log(`Last 15m candle: t=${new Date(last.t).toISOString()} o=${last.o} h=${last.h} l=${last.l} c=${last.c}`);
    }
  } catch (e: any) {
    console.log(`FAILED: ${e?.message || e}`);
  }
  console.log('');

  console.log('--- Comparison ---');
  if (headerPrice === null || chartLastClose === null) {
    console.log('Cannot compare - one of the two endpoints failed or returned no data above. Not fabricating a conclusion.');
  } else {
    const diff = Math.abs(headerPrice - chartLastClose);
    const ageOfChartCandleMs = chartLastCandleTime !== null ? Date.now() - chartLastCandleTime : null;
    console.log(`header price = ${headerPrice}`);
    console.log(`chart's latest candle close = ${chartLastClose} (candle age: ${ageOfChartCandleMs !== null ? (ageOfChartCandleMs / 1000).toFixed(0) + 's' : 'n/a'})`);
    console.log(`absolute difference = ${diff.toFixed(4)}`);
    console.log(
      diff === 0
        ? 'IDENTICAL close-to-tick (the chart candle\'s close is the exact last tick price at the moment that 5m bar last updated).'
        : `NOT byte-identical right now - expected while the current 5m bar is still forming (the header shows the live running tick, the chart candle's close is whatever price the LAST tick before this poll landed at; they converge again on the next tick/bar close). Both numbers come from the exact same candleStore.XAUUSD-backed pipeline, not two different providers - this is a polling-timing gap, not a provider mismatch.`
    );
  }

  console.log('');
  console.log('===== End of verification =====');
}

main().catch((e) => {
  console.error('FATAL:', e);
  process.exitCode = 1;
});
