// Task 5 (2026-08-29 XAUUSD audit follow-up): live production verification of Tasks 1-4, using
// REAL data from the deployed service - not sandbox simulation. This sandbox's egress to the
// production Render URL is blocked (confirmed: `curl` gets "CONNECT tunnel failed, response 403"
// from the org's egress proxy, same as gold-api.com/Yahoo/Binance on this project), so this script
// only ever runs on GitHub Actions' own runners (real internet access) via
// .github/workflows/verify-xau-production.yml - same established workaround this project already
// uses for scripts/backtest-xau-engine.ts.
//
// Every endpoint hit here is PUBLIC (no admin auth) - deliberately chosen that way so this script
// needs no repository secrets and can run read-only against exactly what a real visitor's browser
// already fetches:
//   /api/market/candles       - candleStore.XAUUSD's real OHLC array (Task 1: candleCount, gaps)
//   /api/signals               - the currently live XAUUSD signal, if any (Task 4: current tier)
//   /api/history?pairId=XAUUSD - completed XAUUSD signal history (Task 4/5: tier distribution,
//                                 signal frequency/timing before vs after this deploy)
//
// Prints everything as plain numbers to the job log - no pass/fail judgement is made here about
// whether frequency has "improved enough" (that requires more elapsed time than a same-day check
// can show, see the header comment on the workflow), only real, honest figures.

import { readFileSync } from 'node:fs';

const BASE_URL = process.env.HEV_PRODUCTION_URL || 'https://hevora-terminal-signal-production-2.onrender.com';

// Approximate deploy timestamps (git commit time of the two merges to main for this audit) - used
// only to split history records into before/after buckets for a frequency comparison. Labeled
// "approximate" throughout because Render's actual deploy-live time (after build) lags the git
// push by some build-dependent amount this script has no way to know.
const TASK_1_4_DEPLOY_ISO = '2026-08-29T07:47:58+00:00'; // commit 476646b
const TASK_5_FIX_DEPLOY_ISO = '2026-08-29T08:20:34+00:00'; // commit 8646755

interface Candle { t: number; o: number; h: number; l: number; c: number }
interface CandlesResponse { candles: Record<string, Candle[]>; newestAt: string | null; fetchedAt: string }
interface Signal {
  id: string;
  pairId: string;
  status: string;
  signalTier?: 'MAIN' | 'SCALP';
  createdAt: string;
  strategyMethod: string;
  analysisReasoning?: string;
  takeProfit1?: number;
  takeProfit2?: number;
  takeProfitMax?: number;
}
interface MarketPriceLite { price: number; lastUpdated: string; isStale?: boolean }
interface SignalsResponse { signals: Record<string, Signal | null>; prices: Record<string, MarketPriceLite> }
interface HistoryRecord {
  id: string;
  pairId: string;
  createdAt: string;
  closedAt: string;
  finalStatus: string;
  outcomeCategory: string;
  signalTier?: 'MAIN' | 'SCALP';
}
interface HistoryResponse { success: boolean; history: HistoryRecord[] }

async function fetchJson<T>(path: string): Promise<T> {
  const url = `${BASE_URL}${path}`;
  const res = await fetch(url, { headers: { 'User-Agent': 'HEVORA-XAU-Verify/1.0' } });
  if (!res.ok) {
    throw new Error(`${path} -> HTTP ${res.status}`);
  }
  return (await res.json()) as T;
}

function fmtAgeMinutes(ms: number): string {
  const min = ms / 60000;
  if (min < 60) return `${min.toFixed(1)}min`;
  return `${(min / 60).toFixed(2)}h`;
}

async function main() {
  console.log(`===== Task 5 XAUUSD production verification =====`);
  console.log(`Target: ${BASE_URL}`);
  console.log(`Run at: ${new Date().toISOString()}`);
  console.log('');

  // --- 0. Deploy-sync check (2026-08-31 audit): is Render actually running the commit this repo
  // is currently checked out at, or is it stale?
  //
  // Primary signal: /api/deploy-info's `commit` field, which Render sets from RENDER_GIT_COMMIT -
  // populated automatically by the platform for every deploy, from the exact commit it built. This
  // is compared against `git rev-parse HEAD` on this runner (the commit that triggered this very
  // workflow run), so it is an exact, tooling-independent match, not a guess.
  //
  // Secondary/fallback signal: the JS bundle filename referenced in index.html. Kept only in case
  // the server predates this endpoint (no `commit` in the response) - NOT fully reliable on its
  // own, since vite/esbuild are pinned with caret ranges in package.json and a minor tooling
  // version difference between this runner's build and Render's own build can change minified
  // output (and therefore the content hash) even for byte-identical source. A bundle mismatch alone
  // is a hint, not proof; a `commit` mismatch/match from /api/deploy-info is authoritative.
  console.log('--- [0] Deploy sync: production /api/deploy-info commit vs this runner\'s checked-out commit ---');
  try {
    const { execSync } = await import('node:child_process');
    const localCommit = execSync('git rev-parse HEAD').toString().trim();
    console.log(`This runner is checked out at commit: ${localCommit}`);

    const deployInfoRes = await fetch(`${BASE_URL}/api/deploy-info`, { headers: { 'User-Agent': 'HEVORA-XAU-Verify/1.0' } });
    if (deployInfoRes.ok) {
      const info: any = await deployInfoRes.json().catch(() => null);
      const prodCommit: string | null = info?.commit ?? null;
      console.log(`Production /api/deploy-info: commit=${prodCommit ?? '(null - RENDER_GIT_COMMIT not set, or server predates this endpoint)'} branch=${info?.branch ?? 'null'} processStartedAt=${info?.processStartedAt ?? 'null'}`);
      if (prodCommit) {
        if (prodCommit === localCommit) {
          console.log('VERDICT (authoritative): MATCH - production is running the exact commit that triggered this workflow run. Render is up to date.');
        } else {
          console.log(`VERDICT (authoritative): MISMATCH - production is running commit ${prodCommit}, not ${localCommit}. Render has NOT deployed the latest push.`);
        }
      } else {
        console.log('VERDICT: /api/deploy-info reachable but commit is null - falling back to the bundle-hash heuristic below (server likely predates this endpoint, in which case a redeploy will pick it up and this check becomes authoritative going forward).');
      }
    } else {
      console.log(`Production /api/deploy-info returned HTTP ${deployInfoRes.status} - falling back to the bundle-hash heuristic below.`);
    }

    // Fallback heuristic - see caveat above.
    const localHtml = readFileSync('public/index.html', 'utf-8');
    const localMatch = localHtml.match(/\/assets\/index-[\w-]+\.js/);
    const localBundle = localMatch ? localMatch[0] : null;
    const htmlRes = await fetch(`${BASE_URL}/`, { headers: { 'User-Agent': 'HEVORA-XAU-Verify/1.0' } });
    const prodHtml = await htmlRes.text();
    const prodMatch = prodHtml.match(/\/assets\/index-[\w-]+\.js/);
    const prodBundle = prodMatch ? prodMatch[0] : null;
    console.log(`[fallback heuristic] this commit's bundle: ${localBundle ?? '(not found)'} | production's bundle: ${prodBundle ?? '(not found, HTTP ' + htmlRes.status + ')'} | ${localBundle && prodBundle ? (localBundle === prodBundle ? 'match (consistent with, but not proof of, being up to date)' : 'MISMATCH (consistent with, but not proof of, being stale - could also just be tooling-version drift)') : 'not comparable'}`);
  } catch (e: any) {
    console.error(`FAILED deploy-sync check: ${e?.message || e}`);
  }
  console.log('');

  // --- 1. Candle health (Task 1) ---------------------------------------------------------------
  console.log('--- [1] /api/market/candles (candleStore.XAUUSD - Task 1 self-built candle check) ---');
  try {
    const data = await fetchJson<CandlesResponse>('/api/market/candles');
    const xau = data.candles['XAUUSD'] || [];
    const nowMs = Date.now();
    console.log(`candleCount: ${xau.length} / 150 target`);
    if (xau.length > 0) {
      const oldest = xau[0].t;
      const newest = xau[xau.length - 1].t;
      console.log(`oldest candle: ${new Date(oldest).toISOString()} (${fmtAgeMinutes(nowMs - oldest)} ago)`);
      console.log(`newest candle: ${new Date(newest).toISOString()} (${fmtAgeMinutes(nowMs - newest)} ago)`);
      console.log(`span covered: ${fmtAgeMinutes(newest - oldest)}`);

      let largestGapMinutes = 0;
      let gapCount = 0;
      const gapDetails: string[] = [];
      for (let i = 1; i < xau.length; i++) {
        const gapMin = (xau[i].t - xau[i - 1].t) / 60000;
        if (gapMin > 5.5) {
          gapCount++; // > one 5-minute bar's worth of slack
          gapDetails.push(`  gap ${gapMin.toFixed(1)}min: ${new Date(xau[i - 1].t).toISOString()} -> ${new Date(xau[i].t).toISOString()}`);
        }
        if (gapMin > largestGapMinutes) largestGapMinutes = gapMin;
      }
      console.log(`largestGapMinutes: ${largestGapMinutes.toFixed(1)}`);
      console.log(`bars with a gap > 5.5min before them: ${gapCount} / ${xau.length - 1}`);
      // Frozen-after-restart diagnosis aid: pinpoints exactly when each gap happened so it can be
      // cross-referenced against Render deploy/restart times instead of just knowing one exists.
      if (gapDetails.length > 0) {
        console.log('Gap locations (candle builder restart-recovery diagnosis):');
        for (const line of gapDetails) console.log(line);
      }

      const hoursSinceDeploy = (nowMs - new Date(TASK_1_4_DEPLOY_ISO).getTime()) / 3_600_000;
      console.log(`hours since Task 1-4 deploy: ${hoursSinceDeploy.toFixed(2)}h (12.5h needed for a full 150-bar self-built history)`);
      if (xau.length < 150 && hoursSinceDeploy < 12.5) {
        console.log('VERDICT: candleCount below 150 but deploy is under 12.5h old - consistent with expected cold-start, not a bug.');
      } else if (xau.length < 150 && hoursSinceDeploy >= 12.5) {
        console.log('VERDICT: candleCount still below 150 despite >= 12.5h elapsed - worth investigating (expected to be near-full by now).');
      } else {
        console.log('VERDICT: candleCount at/near the 150-bar target.');
      }
      if (largestGapMinutes > 15) {
        console.log(`VERDICT: largestGapMinutes (${largestGapMinutes.toFixed(1)}) exceeds the 15min staleness threshold - a real gap exists (likely Render free-tier spin-down, see Task 6, or an extended primary-source outage), not just cold-start.`);
      }
    } else {
      console.log('VERDICT: candleStore.XAUUSD is EMPTY - no real OHLC candles have been built yet this server instance.');
    }
  } catch (e: any) {
    console.error(`FAILED to fetch /api/market/candles: ${e?.message || e}`);
  }
  console.log('');

  // --- 2. Current live signal (Task 4 tier) -----------------------------------------------------
  console.log('--- [2] /api/signals (current live XAUUSD signal, if any) ---');
  let productionXauPrice: MarketPriceLite | null = null;
  try {
    const data = await fetchJson<SignalsResponse>('/api/signals');
    const sig = data.signals['XAUUSD'];
    if (sig) {
      console.log(`Active signal: id=${sig.id} status=${sig.status} tier=${sig.signalTier ?? '(not set - predates Task 4/5 deploy or non-XAU logic path)'} createdAt=${sig.createdAt} strategyMethod="${sig.strategyMethod}"`);
      // 2026-08-31 deploy-sync audit: distinguishes a genuinely-old-code 3-level signal from a
      // pre-fix signal that is just still open (takeProfit2 !== takeProfitMax is EXPECTED and
      // correct-by-design for any signal created before the TP1/TP2 restructuring deployed - see
      // that commit's message - it is not evidence of stale code by itself. Cross-reference
      // createdAt above against the [0] deploy-sync verdict to tell the two apart.)
      console.log(`  TP fields: takeProfit1=${sig.takeProfit1} takeProfit2=${sig.takeProfit2} takeProfitMax=${sig.takeProfitMax}`);
      if (sig.takeProfitMax !== undefined && sig.takeProfit2 !== sig.takeProfitMax) {
        console.log(`  NOTE: takeProfit2 (${sig.takeProfit2}) != takeProfitMax (${sig.takeProfitMax}) - this signal still carries the OLD 3-level structure. If [0] above says production IS on the latest commit, this is simply because the signal was created (${sig.createdAt}) before that deploy went live and by design keeps its original levels until it closes - not a sign the fix is missing.`);
      } else if (sig.takeProfitMax !== undefined) {
        console.log(`  NOTE: takeProfit2 === takeProfitMax - this signal already reflects the new 2-level (TP1/TP2) structure.`);
      }
    } else {
      console.log('No active XAUUSD signal right now (null) - engine is between signals or held back by a quality gate.');
    }
    productionXauPrice = data.prices?.['XAUUSD'] ?? null;
    if (productionXauPrice) {
      console.log(`Production header/ticker price (same /api/signals.prices.XAUUSD the frontend polls every 1s): ${productionXauPrice.price} | lastUpdated=${productionXauPrice.lastUpdated} | isStale=${Boolean(productionXauPrice.isStale)}`);
    }
  } catch (e: any) {
    console.error(`FAILED to fetch /api/signals: ${e?.message || e}`);
  }
  console.log('');

  // --- 2b. Price cross-check vs independent live sources (audit point 3: "harga beda dari
  // TradingView") -------------------------------------------------------------------------------
  // TradingView itself has no public quote API to hit programmatically, so this cannot fetch
  // "the exact number TradingView rendered" - the closest honest proxy is comparing our own
  // production price against OTHER independent live spot-gold sources at the same moment, run
  // from a runner with real internet access (unlike the dev sandbox). A few tens of cents to ~$1
  // apart is normal/expected (different OTC spot-gold feeds never print byte-identical ticks);
  // this only flags something as a genuine problem if the gap is large ($1-2+) or our own price
  // is stale.
  console.log('--- [2b] XAUUSD price cross-check: production vs independent live sources ---');
  if (productionXauPrice) {
    const sources: { name: string; price: number | null; note: string }[] = [];

    try {
      const res = await fetch('https://api.gold-api.com/price/XAU', { headers: { 'User-Agent': 'Mozilla/5.0 (HEVORA price audit)' } });
      const json: any = await res.json().catch(() => null);
      const p = typeof json?.price === 'number' ? json.price : null;
      sources.push({ name: 'gold-api.com /price/XAU (our own fallback source)', price: p, note: p === null ? `HTTP ${res.status}, unexpected shape` : 'ok' });
    } catch (e: any) {
      sources.push({ name: 'gold-api.com /price/XAU (our own fallback source)', price: null, note: `fetch failed: ${e?.message || e}` });
    }

    try {
      const res = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/XAUUSD=X?interval=1m&range=1d', { headers: { 'User-Agent': 'Mozilla/5.0 (HEVORA price audit)' } });
      const json: any = await res.json().catch(() => null);
      const closes: number[] | undefined = json?.chart?.result?.[0]?.indicators?.quote?.[0]?.close;
      const lastClose = Array.isArray(closes) ? [...closes].reverse().find((v) => typeof v === 'number') ?? null : null;
      sources.push({ name: 'Yahoo Finance XAUUSD=X (1m, latest close)', price: lastClose, note: lastClose === null ? `HTTP ${res.status}, unexpected shape` : 'ok' });
    } catch (e: any) {
      sources.push({ name: 'Yahoo Finance XAUUSD=X (1m, latest close)', price: null, note: `fetch failed: ${e?.message || e}` });
    }

    console.log(`Production price: ${productionXauPrice.price} (age at fetch: ${fmtAgeMinutes(Date.now() - new Date(productionXauPrice.lastUpdated).getTime())})`);
    for (const s of sources) {
      if (s.price === null) {
        console.log(`  ${s.name}: UNAVAILABLE (${s.note})`);
        continue;
      }
      const diff = productionXauPrice.price - s.price;
      console.log(`  ${s.name}: ${s.price} | diff vs production: ${diff >= 0 ? '+' : ''}${diff.toFixed(2)}`);
    }
    const validDiffs = sources.filter((s) => s.price !== null).map((s) => Math.abs(productionXauPrice!.price - s.price!));
    if (validDiffs.length === 0) {
      console.log('VERDICT: no independent source reachable this run - cannot confirm or rule out a real discrepancy.');
    } else {
      const maxDiff = Math.max(...validDiffs);
      if (productionXauPrice.isStale) {
        console.log(`VERDICT: production price is flagged isStale=true - any diff here is expected and not informative until a live tick resumes.`);
      } else if (maxDiff > 2) {
        console.log(`VERDICT: max diff ${maxDiff.toFixed(2)} EXCEEDS the $1-2 normal-OTC-spread range - worth investigating fetchGold/fetchGoldApiPrice parsing.`);
      } else if (maxDiff > 1) {
        console.log(`VERDICT: max diff ${maxDiff.toFixed(2)} is at the edge of normal OTC provider spread - borderline, re-check on another run before concluding a bug.`);
      } else {
        console.log(`VERDICT: max diff ${maxDiff.toFixed(2)} is within normal OTC spot-gold provider variance - not a bug.`);
      }
    }
  } else {
    console.log('SKIPPED: no production price available from /api/signals to compare against.');
  }
  console.log('');

  // --- 3. Signal history: frequency + tier distribution, before vs after this deploy ------------
  console.log('--- [3] /api/history?pairId=XAUUSD (completed signal history - Task 4/5 frequency + tier check) ---');
  try {
    const data = await fetchJson<HistoryResponse>('/api/history?pairId=XAUUSD');
    const records = (data.history || []).slice().sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    console.log(`Total XAUUSD records in history store: ${records.length}`);

    const nowMs = Date.now();
    const last24h = records.filter((r) => nowMs - new Date(r.createdAt).getTime() <= 24 * 3_600_000);
    const last48h = records.filter((r) => nowMs - new Date(r.createdAt).getTime() <= 48 * 3_600_000);
    console.log(`Records created in last 24h: ${last24h.length}`);
    console.log(`Records created in last 48h: ${last48h.length}`);

    const tierCounts: Record<string, number> = { MAIN: 0, SCALP: 0, 'not set': 0 };
    for (const r of records) {
      if (r.signalTier === 'MAIN') tierCounts.MAIN++;
      else if (r.signalTier === 'SCALP') tierCounts.SCALP++;
      else tierCounts['not set']++;
    }
    console.log(`Tier distribution (ALL recorded history - "not set" = closed before the Task 5 signalTier-in-history fix, or another pair's generic path): MAIN=${tierCounts.MAIN} SCALP=${tierCounts.SCALP} not-set=${tierCounts['not set']}`);

    const deployMs = new Date(TASK_1_4_DEPLOY_ISO).getTime();
    const beforeDeploy = records.filter((r) => new Date(r.createdAt).getTime() < deployMs);
    const afterDeploy = records.filter((r) => new Date(r.createdAt).getTime() >= deployMs);
    console.log(`Records created BEFORE Task 1-4 deploy (${TASK_1_4_DEPLOY_ISO}): ${beforeDeploy.length}`);
    console.log(`Records created AFTER Task 1-4 deploy: ${afterDeploy.length}`);

    const avgGapMinutes = (recs: HistoryRecord[]): number | null => {
      if (recs.length < 2) return null;
      const sorted = recs.slice().sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      let totalGap = 0;
      for (let i = 1; i < sorted.length; i++) {
        totalGap += new Date(sorted[i].createdAt).getTime() - new Date(sorted[i - 1].createdAt).getTime();
      }
      return totalGap / (sorted.length - 1) / 60000;
    };

    const beforeAvgGap = avgGapMinutes(beforeDeploy.slice(-20)); // last 20 before deploy, so an old, unrelated slow period doesn't dominate
    const afterAvgGap = avgGapMinutes(afterDeploy);
    console.log(`Avg minutes between signals, last 20 BEFORE deploy: ${beforeAvgGap !== null ? beforeAvgGap.toFixed(1) : 'not enough records'}`);
    console.log(`Avg minutes between signals AFTER deploy: ${afterAvgGap !== null ? afterAvgGap.toFixed(1) : 'not enough records yet - too little time elapsed since deploy for a meaningful average'}`);

    console.log('');
    console.log('Most recent 10 XAUUSD history records (newest first):');
    for (const r of records.slice(-10).reverse()) {
      console.log(`  ${r.createdAt} -> ${r.closedAt} | tier=${r.signalTier ?? '(not set)'} | outcome=${r.outcomeCategory} | finalStatus=${r.finalStatus}`);
    }
  } catch (e: any) {
    console.error(`FAILED to fetch /api/history: ${e?.message || e}`);
  }

  console.log('');
  console.log('===== End of Task 5 verification - report these numbers as-is, do not round up to "looks fine" =====');
}

main().catch((e) => {
  console.error('FATAL:', e);
  process.exitCode = 1;
});
